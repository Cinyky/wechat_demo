var siteinfo = {
    'uniacid': '-1',
    'acid': '-1',
    'version': '1.0.0',
    'siteroot': 'https://www.abc.com/app/index.php',
};
module.exports = siteinfo;